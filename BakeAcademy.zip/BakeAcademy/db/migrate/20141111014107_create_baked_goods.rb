class CreateBakedGoods < ActiveRecord::Migration
  def change
    create_table :baked_goods do |t|
      t.string :name, null: false

      t.timestamps
    end
  end
end
