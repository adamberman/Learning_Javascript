require 'test_helper'

class BakedGoodTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
