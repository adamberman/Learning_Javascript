require 'test_helper'

class BakedGoodsHelperTest < ActionView::TestCase
end
