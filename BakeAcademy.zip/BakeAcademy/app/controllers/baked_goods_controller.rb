class BakedGoodsController < ApplicationController
  def index
    @baked_goods = BakedGood.all

    respond_to do |format|
      format.html { render :index }
      format.json { render json: @baked_goods }
    end
  end

  def create
    @baked_good = BakedGood.new(baked_good_params)
    if @baked_good.save
      respond_to do |format|
        format.html { redirect_to baked_goods_url }
        format.json { render json: @baked_good }
      end

    else
      render :index
    end
  end
end

private

def baked_good_params
  params.require(:baked_good).permit(:name)
  # {baked_goods: {name: "Vanilla Cupcake"}}
end
