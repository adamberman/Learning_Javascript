class OrdersController < ApplicationController
  def create

    @order = current_user.orders.new(order_params)
    if @order.save
      respond_to do |format|
        format.html { redirect_to root_url }
        format.json { render :show }
      end
    else
      render json: @order.errors.full_messages
    end
  end

  private

  def order_params
    params.require(:order).permit(:baked_good_id)
  end
end
