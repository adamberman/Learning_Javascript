class Order < ActiveRecord::Base
  belongs_to :baked_good
  belongs_to :user
end
