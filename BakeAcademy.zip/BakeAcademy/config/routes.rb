Rails.application.routes.draw do
  root to: "baked_goods#index"
  resources :baked_goods, only: [:index, :create]
  resources :orders, only: [:create]
  resources :users, only: [:new, :create]
  resource :session, only: [:new, :create, :destroy]
end
