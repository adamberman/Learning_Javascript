require 'rails_helper'

RSpec.describe OrdersController, :type => :controller do

end
